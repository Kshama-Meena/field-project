import express from "express";
import User from "../models/userModel.js";

const router = express.Router();

router.get("/get-users", async (req, res) => {
  try {
    const users = await User.find({ role: "user" });
    res.json({ success: true, users });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

export default router;
