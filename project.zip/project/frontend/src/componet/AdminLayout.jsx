import React, { useState } from 'react';
import Sidebar from './Sidebar';
import DashboardContent from './context/DashboardContent';

const AdminLayout = () => {
  const brandGreen = 'bg-[#008080]'; 
  const textGreen = 'text-[#008080]';
  const brandOrange = 'bg-[#FF6600]';
  const hoverOrange = 'hover:bg-[#E65C00]';

  const [activeSection, setActiveSection] = useState('dashboard');

  // ✅ All Sidebar Options (Dynamic)
  const sidebarMenu = [
    { key: "dashboard", label: "Dashboard", icon: "📊" },
    { key: "categories", label: "Categories", icon: "🗂️" },
    { key: "products", label: "Products", icon: "🍎" },
    { key: "users", label: "Users", icon: "👤" },
    { key: "orders", label: "Orders", icon: "📦" },
    { key: "reports", label: "Reports", icon: "📑" },
    { key: "settings", label: "Settings", icon: "⚙️" },
  ];

  const notificationCount = 3;
  const adminName = "Admin Fresh";

  return (
    <div className="flex h-screen bg-gray-100 font-sans">

      {/* SIDEBAR — dynamic menu send */}
      <Sidebar 
        activeSection={activeSection} 
        setActiveSection={setActiveSection} 
        brandGreen={brandGreen}
        sidebarMenu={sidebarMenu}   // <-- DYNAMIC MENU
      />

      {/* MAIN CONTENT */}
      <div className="flex-1 flex flex-col overflow-hidden">

        {/* TOP BAR */}
        <header className="flex items-center justify-between p-4 bg-white shadow-md">
          
          <h1 className={`text-2xl font-bold ${textGreen} ml-2 hidden sm:block`}>
            {sidebarMenu.find(item => item.key === activeSection)?.label} Management
          </h1>

          <div className="flex items-center space-x-4">

            {/* Search */}
            <input 
              type="text" 
              placeholder="Search products, orders..." 
              className="p-2 border border-gray-300 rounded-lg focus:ring-1 focus:ring-[#008080] focus:border-[#008080] w-40 sm:w-64"
            />

            {/* Notification */}
            <div className="relative">
              <span className={`text-gray-600 hover:${textGreen} cursor-pointer text-xl`}>🔔</span>
              {notificationCount > 0 && (
                <span className={`absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold text-white transform translate-x-1/2 -translate-y-1/2 ${brandOrange} rounded-full`}>
                  {notificationCount}
                </span>
              )}
            </div>

            {/* Profile */}
            <div className="flex items-center cursor-pointer p-2 rounded-lg hover:bg-gray-100">
              <img 
                className="h-8 w-8 rounded-full object-cover mr-2" 
                src="https://picsum.photos/50/50?grayscale" 
                alt="Admin Profile"
              />
              <span className="text-sm font-medium text-gray-700 hidden md:block">{adminName}</span>
            </div>
          </div>
        </header>

        {/* MAIN CONTENT */}
        <main className="flex-1 overflow-x-hidden overflow-y-auto p-6">
          <DashboardContent 
            activeSection={activeSection} 
            brandOrange={brandOrange} 
            textGreen={textGreen} 
            brandGreen={brandGreen}
            hoverOrange={hoverOrange}
          />
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;