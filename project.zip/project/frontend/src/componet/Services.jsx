function Services() {
  return <h1 className="pt-28 text-center">Services Page</h1>;
}
export default Services;
