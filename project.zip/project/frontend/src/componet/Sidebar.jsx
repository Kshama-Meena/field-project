const Sidebar = ({ activeSection, setActiveSection, brandGreen, sidebarMenu }) => {
  return (
    <div className={`w-64 text-white ${brandGreen} p-5`}>
      
      <h2 className="text-xl font-bold mb-6">Admin Panel</h2>

      {sidebarMenu.map((item) => (
        <div
          key={item.key}
          onClick={() => setActiveSection(item.key)}
          className={`cursor-pointer p-3 mb-2 rounded-lg flex items-center gap-3 
            ${activeSection === item.key ? "bg-white text-black shadow" : "hover:bg-[#006666]"}`}
        >
          <span>{item.icon}</span>
          <span>{item.label}</span>
        </div>
      ))}

    </div>
  );
};

export default Sidebar;
