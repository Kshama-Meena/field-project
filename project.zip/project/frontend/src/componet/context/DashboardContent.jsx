import React, { useEffect, useState } from "react";
import axios from "axios";
import UsersPage from "../pages/UsersPage"; // <-- ADD THIS IMPORT
import ProductsPage from "../pages/ProductsPage"; // <-- ADD THIS IMPORT

// Status badge color handler
const getStatusBadge = (status) => {
  switch (status) {
    case "Delivered":
      return "bg-green-200 text-green-800";
    case "Processing":
      return "bg-yellow-200 text-yellow-800";
    case "Cancelled":
      return "bg-red-200 text-red-800";
    case "Shipped":
      return "bg-blue-200 text-blue-800";
    default:
      return "bg-gray-200 text-gray-800";
  }
};

const DashboardContent = ({
  activeSection,
  brandOrange,
  textGreen,
  brandGreen,
  hoverOrange,
}) => {
  
  // 🟦 USERS PAGE SHOW
  if (activeSection === "users") {
    return <UsersPage />;
  }
  if (activeSection === "products") {
  return <ProductsPage />;
}

  // 🟩 Dashboard Data
  const [kpi, setKpi] = useState({
    revenue: 0,
    orders: 0,
    customers: 0,
    outOfStock: 0,
  });

  const [recentOrders, setRecentOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  const borderGreenClass = brandGreen.replace("bg-", "border-");

  // Fetch Dashboard Data
  useEffect(() => {
    const loadDashboard = async () => {
      try {
        const res = await axios.get("http://localhost:5000/api/dashboard/data");
        setKpi(res.data.kpi);
        setRecentOrders(res.data.recentOrders);
      } catch (err) {
        console.error("Dashboard load error:", err);
      } finally {
        setLoading(false);
      }
    };

    loadDashboard();
  }, []);

  // If not Dashboard section
  if (activeSection !== "dashboard") {
    return (
      <div className="p-10 text-center text-xl text-gray-500">
        {activeSection.charAt(0).toUpperCase() + activeSection.slice(1)} Section
        is under development.
      </div>
    );
  }

  // Loading
  if (loading) {
    return (
      <div className="p-10 text-center text-xl text-gray-500">
        Loading dashboard...
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Your entire dashboard UI remains same */}
      {/* KPI CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className={`bg-white p-6 rounded-xl shadow-lg border-l-4 ${borderGreenClass}`}>
          <p className="text-sm text-gray-500">Total Revenue</p>
          <h2 className="text-3xl font-bold text-green-600">₹{kpi.revenue}</h2>
        </div>

        <div className={`bg-white p-6 rounded-xl shadow-lg border-l-4 ${borderGreenClass}`}>
          <p className="text-sm text-gray-500">New Orders</p>
          <h2 className="text-3xl font-bold text-orange-600">{kpi.orders}</h2>
        </div>

        <div className={`bg-white p-6 rounded-xl shadow-lg border-l-4 ${borderGreenClass}`}>
          <p className="text-sm text-gray-500">Customers Today</p>
          <h2 className="text-3xl font-bold text-blue-600">{kpi.customers}</h2>
        </div>

        <div className={`bg-white p-6 rounded-xl shadow-lg border-l-4 ${borderGreenClass}`}>
          <p className="text-sm text-gray-500">Out of Stock</p>
          <h2 className="text-3xl font-bold text-red-600">{kpi.outOfStock}</h2>
        </div>
      </div>

      {/* Chart + Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-6 rounded-xl shadow-lg">
          <h3 className={`text-xl font-bold ${textGreen} mb-4`}>
            Last 7 Days Sales Trend
          </h3>
          <div className="h-64 flex items-center justify-center bg-gray-50 border border-dashed border-gray-300 rounded-lg">
            [Line Chart Placeholder]
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-lg space-y-4">
          <h3 className={`text-xl font-bold ${textGreen} mb-4`}>
            Quick Actions
          </h3>
          <button className={`w-full py-3 px-4 text-white font-semibold rounded-lg shadow-md ${brandOrange} transition ${hoverOrange}`}>
            + Add New Product
          </button>
          <button className={`w-full py-3 px-4 text-white font-semibold rounded-lg shadow-md ${brandGreen} hover:bg-green-700`}>
            Manage Inventory
          </button>
        </div>
      </div>

      {/* Recent Orders */}
      <div className="bg-white p-6 rounded-xl shadow-lg">
        <h3 className={`text-xl font-bold ${textGreen} mb-4`}>Recent Orders</h3>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3">Order ID</th>
                <th className="px-6 py-3">Customer</th>
                <th className="px-6 py-3">Total</th>
                <th className="px-6 py-3">Status</th>
                <th className="px-6 py-3">Actions</th>
              </tr>
            </thead>

            <tbody className="bg-white divide-y divide-gray-200">
              {recentOrders.map((order) => (
                <tr key={order._id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">{order.orderId}</td>
                  <td className="px-6 py-4">{order.customerName}</td>
                  <td className="px-6 py-4 font-bold">₹{order.total}</td>
                  <td className="px-6 py-4">
                    <span
                      className={`px-2 py-1 text-xs rounded-full ${getStatusBadge(
                        order.status
                      )}`}
                    >
                      {order.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <button className="text-green-600 mr-3">View</button>
                    <button className="text-red-600">Cancel</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {recentOrders.length === 0 && (
            <p className="text-center text-gray-500 py-4">
              No recent orders found.
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default DashboardContent;
