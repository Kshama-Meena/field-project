import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";

const EditProduct = () => {
  const { id } = useParams();
  const [form, setForm] = useState(null);

  useEffect(() => {
    (async () => {
      const res = await axios.get("http://localhost:5000/api/products");
      const prod = res.data.find((p) => p._id === id);
      setForm(prod);
    })();
  }, [id]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const updateProduct = async (e) => {
    e.preventDefault();
    await axios.put(`http://localhost:5000/api/products/update/${id}`, form);
    alert("Product updated!");
    window.location.href = "/admin/products";
  };

  if (!form) return <p>Loading...</p>;

  return (
    <form onSubmit={updateProduct} className="p-6 space-y-4">
      <h2 className="text-2xl font-semibold">Edit Product</h2>

      <input className="border p-2 w-full" name="name" value={form.name} onChange={handleChange} />

      <input className="border p-2 w-full" name="price" value={form.price} onChange={handleChange} />

      <input className="border p-2 w-full" name="category" value={form.category} onChange={handleChange} />

      <input className="border p-2 w-full" name="image" value={form.image} onChange={handleChange} />

      <textarea className="border p-2 w-full" name="text" value={form.text} onChange={handleChange} />

      <button className="bg-blue-600 text-white px-4 py-2 rounded">
        Update Product
      </button>
    </form>
  );
};

export default EditProduct;
