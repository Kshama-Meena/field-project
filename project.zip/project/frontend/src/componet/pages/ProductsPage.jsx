import React, { useEffect, useState } from "react";
import axios from "axios";

const ProductsPage = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadProducts = async () => {
    const res = await axios.get("http://localhost:5000/api/products");
    setProducts(res.data);
    setLoading(false);
  };

  const deleteProduct = async (id) => {
    if (!window.confirm("Are you sure?")) return;

    await axios.delete(`http://localhost:5000/api/products/delete/${id}`);
    loadProducts();
  };

  useEffect(() => {
    loadProducts();
  }, []);

  if (loading) return <p>Loading...</p>;

  return (
    <div className="p-6">
      <div className="flex justify-between mb-4">
        <h2 className="text-2xl font-semibold">All Products</h2>
        <a
          href="/admin/add-product"
          className="bg-green-600 text-white px-4 py-2 rounded"
        >
          + Add Product
        </a>
      </div>

      <table className="w-full border">
        <thead>
          <tr className="bg-gray-200">
            <th className="border p-2">Image</th>
            <th className="border p-2">Name</th>
            <th className="border p-2">Category</th>
            <th className="border p-2">Price</th>
            <th className="border p-2">Actions</th>
          </tr>
        </thead>

        <tbody>
          {products.map((p) => (
            <tr key={p._id}>
              <td className="border p-2">
                <img src={p.image} className="h-12 mx-auto" />
              </td>
              <td className="border p-2">{p.name}</td>
              <td className="border p-2">{p.category}</td>
              <td className="border p-2">₹{p.price}</td>
              <td className="border p-2 flex gap-2 justify-center">
                <a
                  href={`/edit-product/${p._id}`}
                  className="px-3 py-1 bg-blue-600 text-white rounded"
                >
                  Edit
                </a>

                <button
                  onClick={() => deleteProduct(p._id)}
                  className="px-3 py-1 bg-red-600 text-white rounded"
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ProductsPage;
